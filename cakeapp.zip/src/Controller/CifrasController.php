<?php
declare(strict_types=1);

namespace App\Controller;
class CifrasController extends AppController
{
	public function index()
	{
		$cifras = $this->paginate($this->Cifras);
		$this->set(compact('cifras'));
	}

	public function view($id = null)
	{
		$cifras = $this->Cifras->get($id);
		$this->set('cifras', $cifras);
	}

	/*public function add()
	{
		$cifras = $this->Cifras->newEntity();
		if ($this->request->is('post')) {
			$cifras = $this->Cifras->patchEntity($cifras, $this->request->getData());
			$cifras->user_id = $this->Auth->user('id');
			if ($this->Cifras->save($cifras)) {
				$this->Flash->success('A cifras foi salva.');
				return $this->redirect(['action' => 'index']);
			}
			$this->Flash->error('Erro ao adicionar a cifra. Tente outra vez mais tarde.');
		}
		$cifras = $this->Cifras->Cifras->find('list');
		$this->set(compact('cifras'));
		$this->viewBuilder()->setOption('serialize', ['cifras']);
	}*/

	public function add()
	{
		$cifras = $this->Cifras->newEmptyEntity();
		if ($this->request->is('post')) {
			$cifras = $this->Cifras->patchEntity($cifras, $this->request->getData());
			if ($this->Cifras->save($cifras)) {
				$this->Flash->success(__('A cifra foi salva.'));

				return $this->redirect(['action' => 'index']);
			}
			$this->Flash->error(__('Erro ao salvar o cifra. Tente outra vez mais tarde.'));
		}
		$this->set(compact('cifras'));
	}

	public function edit($id = null)
	{
		$cifras = $this->Cifras->get($id);
		if ($this->request->is(['patch', 'post', 'put'])) {
			$cifras = $this->Cifras->patchEntity($cifras, $this->request->getData()); 
			if ($this->Cifras->save($cifras)) {
				$this->Flash->success(__('A cifras foi salva.'));
				return $this->redirect(['action' => 'index']);
			}
			$this->Flash->error(__('Erro ao salvar a cifras. Tente outra vez mais tarde.'));
		}
		$this->set(compact('cifras'));
		$this->viewBuilder()->setOption('serialize', ['cifras']);
	}

	public function delete($id = null)
	{
		$this->request->allowMethod(['post', 'delete']);
		$cifras = $this->Cifras->get($id);
		if ($this->Cifras->delete($cifras)) {
			$this->Flash->success(__('A cifras foi apagada.'));
		} else {
			$this->Flash->error(__('Erro ao salvar a cifras. Tente outra vez mais tarde.'));
		}
		return $this->redirect(['action' => 'index']);
	}
}