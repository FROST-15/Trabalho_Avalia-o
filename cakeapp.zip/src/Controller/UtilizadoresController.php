<?php
declare(strict_types=1);

namespace App\Controller; 
class UtilizadoresController extends AppController
{
	public function index()
	{
		$utilizadores = $this->paginate($this->Utilizadores);
		$this->set(compact('utilizadores'));
	}

	public function view($id = null)
	{
		$utilizadores = $this->Utilizadores->get($id);
		$this->set('utilizadores', $utilizadores);
	}

	public function add()
	{
		$utilizadores = $this->Utilizadores->newEmptyEntity();
		if ($this->request->is('post')) {
			$utilizadores = $this->Utilizadores->patchEntity($utilizadores, $this->request->getData());
			if ($this->Utilizadores->save($utilizadores)) {
				$this->Flash->success(__('O utilizador foi salvo.'));

				return $this->redirect(['action' => 'index']);
			}
			$this->Flash->error(__('Erro ao salvar o utilizador. Tente outra vez mais tarde.'));
		}
		$this->set(compact('utilizadores'));
	}



	public function edit($id = null)
	{
		$utilizadores = $this->Utilizadores->get($id);
		if ($this->request->is(['patch', 'post', 'put'])) {
			$utilizadores = $this->Utilizadores->patchEntity($utilizadores, $this->request->getData()); 
			if ($this->Utilizadores->save($nome)) {
				$this->Flash->success(__('O utilizador foi editado.'));
				return $this->redirect(['action' => 'index']);
			}
			$this->Flash->error(__('Erro ao salvar utilizador. Tente outra vez mais tarde.'));
		}
		$this->set(compact('utilizador'));
		$this->viewBuilder()->setOption('serialize', ['utilizador']);
	}
	

	public function delete($id = null)
	{
		$this->request->allowMethod(['post', 'delete']);
		$utilizadores = $this->Utilizadores->get($id);
		if ($this->Utilizadores->delete($utilizadores)) {
			$this->Flash->success(__('O utilizador foi eliminado.'));
		} else {
			$this->Flash->error(__('Erro ao eliminar o utilizador. Tente outra vez mais tarde.'));
		}
		return $this->redirect(['action' => 'index']);
	}
}
?>