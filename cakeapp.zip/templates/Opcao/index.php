<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Bookmark[]|\Cake\Collection\CollectionInterface $bookmarks
 */
?>
<div class="utilizadores index content">
	<?= $this->Html->link(__('Nova Opção'), ['action' => 'add'], ['class' => 'button float-right']) ?>
	<h3><?= __('Opções') ?></h3>
	<div class="table-responsive">
		<table>
			<thead>
				<tr>
					<th><?= $this->Paginator->sort('id') ?></th>
					<th><?= $this->Paginator->sort('Opções') ?></th> 
					<th class="actions"><?= __('Ações') ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($opcoes as $opcoes): ?>
					<tr>
						<td><?= $this->Number->format($opcoes->id) ?></td>
						<td><?= h($opcoes->opcao) ?></td> 
						<td class="actions">
							<?= $this->Html->link(__('Ver'), ['action' => 'view', $opcoes->id]) ?>
							<?= $this->Html->link(__('Editar'), ['action' => 'edit', $opcoes->opcao]) ?>
							<?= $this->Form->postLink(__('Apagar'), ['action' => 'delete', $opcoes->id], ['confirm' => __('Tem a certeza que deseja eliminar a opção  {0} ?', $opcoes->id)]) ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	
</div>
