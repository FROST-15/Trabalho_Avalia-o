<div class="row">
	<aside class="column">
		<div class="side-nav">
			<h4 class="heading"><?= __('Actions') ?></h4>
			<?= $this->Form->postLink(
				__('Delete'),
				['action' => 'delete', $opcoes->id],
				['confirm' => __('Tem a certeza que deseja eliminar a opção {0} ?', $opcoes->id), 'class' => 'side-nav-item']
			) ?>
			<?= $this->Html->link(__('Listar Opções'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
		</div>
	</aside>
	<div class="column-responsive column-80">
		<div class="opcoes form content">
			<?= $this->Form->create($opcoes) ?>
			<fieldset>
				<legend><?= __('Editar Opção') ?></legend>
				<?php echo $this->Form->control('nome'); ?>
			</fieldset>
			<?= $this->Form->button(__('Editar')) ?>
			<?= $this->Form->end() ?>
		</div>
	</div>
</div>
