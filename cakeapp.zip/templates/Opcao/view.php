<div class="row">
	<aside class="column">
		<div class="side-nav">
			<h4 class="heading"><?= __('Actions') ?></h4>
			<?= $this->Html->link(__('Editar Opção'), ['action' => 'edit', $utilizadores->nome], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Eliminar Opção'), 
            ['action' => 'delete', $utilizadores->id], 
            ['confirm' => __('Tem a certeza que deseja eliminar a opção  {0} ??', $utilizadores->id), 'class' => 'side-nav-item']) ?>
			<?= $this->Html->link(__('Listar Opções'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
			<?= $this->Html->link(__('Nova Opção'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
		</div>
	</aside>
	<div class="column-responsive column-80">
		<div class="bookmarks view content">
			<h3><?= h($opcoes->opcao) ?></h3>
			<table>
				<tr>
					<th><?= __('Id') ?></th>
					<td><?= $this->Number->format($opcoes->id) ?></td>
				</tr>
				<tr>
					<th><?= __('Nome') ?></th>
					<td><?= h($opcoes->opcao) ?></td>
				</tr> 
			</table>
		</div>
	</div>
</div>