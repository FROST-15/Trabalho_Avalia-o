<div class="row">
	<aside class="column">
		<div class="side-nav">
			<h4 class="heading"><?= __('Actions') ?></h4>
			<?= $this->Form->postLink(
				__('Delete'),
				['action' => 'delete', $utilizadores->id],
				['confirm' => __('Tem a certeza que deseja eliminar o utilizador {0} ?', $utilizadores->id), 'class' => 'side-nav-item']
			) ?>
			<?= $this->Html->link(__('Listar Utilizadores'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
		</div>
	</aside>
	<div class="column-responsive column-80">
		<div class="receitas form content">
			<?= $this->Form->create($cifras) ?>
			<fieldset>
				<legend><?= __('Editar Utilizadores') ?></legend>
				<?php echo $this->Form->control('nome'); ?>
			</fieldset>
			<?= $this->Form->button(__('Editar')) ?>
			<?= $this->Form->end() ?>
		</div>
	</div>
</div>
