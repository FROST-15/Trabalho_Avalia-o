<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Ações') ?></h4>
            <?= $this->Html->link(__('Lista de utilizadores'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>    
    <div class="column-responsive column-80">
        <div class="Utilizadores form content">
            <?= $this->Form->create($utilizadores) ?>
            <fieldset>
                <legend><?= __('Adicionar Utilizadores') ?></legend>
                <?php echo $this->Form->control('nome'); ?>
            </fieldset>
            <?= $this->Form->button(__('Adicionar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
