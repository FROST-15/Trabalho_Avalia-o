<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Bookmark[]|\Cake\Collection\CollectionInterface $bookmarks
 */
?>
<div class="utilizadores index content">
	<?= $this->Html->link(__('Novo Utilizador'), ['action' => 'add'], ['class' => 'button float-right']) ?>
	<h3><?= __('Utilizadores') ?></h3>
	<div class="table-responsive">
		<table>
			<thead>
				<tr>
					<th><?= $this->Paginator->sort('id') ?></th>
					<th><?= $this->Paginator->sort('Utilizadores') ?></th> 
					<th class="actions"><?= __('Ações') ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($utilizadores as $utilizadores): ?>
					<tr>
						<td><?= $this->Number->format($utilizadores->id) ?></td>
						<td><?= h($utilizadores->nome) ?></td> 
						<td class="actions">
							<?= $this->Html->link(__('Ver'), ['action' => 'view', $utilizadores->id]) ?>
							<?= $this->Html->link(__('Editar'), ['action' => 'edit', $utilizadores->nome]) ?>
							<?= $this->Form->postLink(__('Apagar'), ['action' => 'delete', $utilizadores->id], ['confirm' => __('Tem a certeza que deseja eliminar o utilizador  {0} ?', $utilizadores->id)]) ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	
</div>
