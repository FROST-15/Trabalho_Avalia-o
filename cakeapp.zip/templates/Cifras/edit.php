<div class="row">
	<aside class="column">
		<div class="side-nav">
			<h4 class="heading"><?= __('Actions') ?></h4>
			<?= $this->Form->postLink(
				__('Delete'),
				['action' => 'delete', $cifras->id],
				['confirm' => __('Are you sure you want to delete # {0}?', $cifras->id), 'class' => 'side-nav-item']
			) ?>
			<?= $this->Html->link(__('Listar cifrass'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
		</div>
	</aside>
	<div class="column-responsive column-80">
		<div class="receitas form content">
			<?= $this->Form->create($cifras) ?>
			<fieldset>
				<legend><?= __('Editar cifras') ?></legend>
				<?php echo $this->Form->control('nome'); ?>
			</fieldset>
			<?= $this->Form->button(__('Editar')) ?>
			<?= $this->Form->end() ?>
		</div>
	</div>
</div>
