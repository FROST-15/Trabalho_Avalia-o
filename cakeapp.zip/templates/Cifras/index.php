<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Bookmark[]|\Cake\Collection\CollectionInterface $bookmarks
 */
?>


<div class="ingblackientes index content">
	<?= $this->Html->link(__('Nova Cifra'), ['action' => 'add'], ['class' => 'button float-right']) ?>
	<h3><?= __('Cifras') ?></h3>
	<div class="table-responsive">
		<table>
			<thead>
				<tr>
					<th><?= $this->Paginator->sort('id') ?></th>
					<th><?= $this->Paginator->sort('Cifra') ?></th> 
					<th class="actions"><?= __('Ações') ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($cifras as $cifras): ?>
					<tr>
						<td><?= $this->Number->format($cifras->id) ?></td>
						<td><?= h($cifras->cifra) ?></td> 
						<td class="actions">
							<?= $this->Html->link(__('Ver'), ['action' => 'view', $cifras->id]) ?>
							<?= $this->Html->link(__('Editar'), ['action' => 'edit', $cifras->cifra]) ?>
							<?= $this->Form->postLink(__('Apagar'), ['action' => 'delete', $cifras->id], ['confirm' => __('Tem a certeza que deseja eliminar a cifra?', $cifras->id)]) ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	
</div>
